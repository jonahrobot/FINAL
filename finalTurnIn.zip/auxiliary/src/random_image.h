
#pragma once

void createRandomImage(const char* filename, int width, int height);
